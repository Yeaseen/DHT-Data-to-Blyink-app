<!--
Thanks for using TinyGSM!

Before opening an issue, please make sure you've read the README.
We do not respond to general questions here, use gitter chat for that.
Please provide the following information for all issues.
The issues that do not contain the relevant information may be rejected.
-->

TinyGSM version: <!-- always try to use the latest -->
Hardware: <!-- modem model, main board type, etc -->

### Scenario, steps to reproduce
<!-- What you are trying to achieve and you can't? -->

### Expected result
<!-- What are you expecting to happen as the consequence of above reproduction steps? -->

### Actual result
<!-- What actually happens after the reproduction steps? Include the error output or a link to a gist if possible. -->

### AT command log
<!-- The AT commands log you get using StreamDebugger or any other debugging method -->
